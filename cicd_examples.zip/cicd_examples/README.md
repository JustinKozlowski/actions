# CICD_Examples

The following folders can be used for 
testing out GitLab Cicd Pipelines as well as basic
DevOps Practices

To use this repository, simply uncomment sections of the
`.gitlab-ci.yml` file in the base directory.

### `/hello_world`
This folder contains the simplest .gitlab-ci.yml to run a
pipeline within M&T. It will echo hello world

### `/unit_test`
Often Continuous Integration is maintained by unit testing.
This folder contains a simple python program that is
unit tested by the pipeline. If the testing fails, the 
pipeline fails

### `/simple_package`
For Continuous Deployment, we can use a pipeline to push our
code to a remote repository that others can pull from. This
example pushes our python code to M&Ts JFrog Artifactory. We
also use this example to show other coding standards that pipelines
can check such as linting and testing coverage.

### `/web_app`
For Continuous Deployment, we can use a pipeline to push our code
to a server. In this example, we push our code to M&Ts Sandbox
OpenShift environment. This involves common deployment actions
including building our image, deploying it, and verifying the
deployment.

### `/integrated_app`
This is a work in progress. Hopefully, this will use artifactory
to pull the deployment for openshift, and changes to the
package in artifactory will trigger a new deployment.
