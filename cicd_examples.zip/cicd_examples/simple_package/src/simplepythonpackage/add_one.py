"""A function that adds 1"""


def add_one(num):
    """A function that adds 1"""
    return num + 1
    # x = 1
