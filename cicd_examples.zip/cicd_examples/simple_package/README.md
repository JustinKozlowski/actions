# Example for Unit Testing

1) Show pipeline works
2) Uncomment line in add_one
3) See pylint, coverage fail
