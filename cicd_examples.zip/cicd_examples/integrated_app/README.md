
https://git-started.mtb.com/#/Documentation/OSE/GitLabSharedRunner?id=required-gitlab-environment-variables
